package GeneticAI;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

public class RunAI {

	public static void StartAI() {
		try {
			Robot r = new Robot();
			int[][] genes = GeneGenerator.CreateGenes();
			for (int i = 0; i < genes.length; i++) {
				for (int j = 0; j < genes[i].length; j++) {	
					if(genes[i][j] == 0) {
						r.keyPress(KeyEvent.VK_RIGHT);
					}
					
//					if(genes[i][j] == 1) {
//						r.keyPress(KeyEvent.VK_LEFT);
//					}
					
					if(genes[i][j] == 2) {
						r.keyPress(KeyEvent.VK_X);
					}



				}
			}

		} catch (AWTException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
	}
}
